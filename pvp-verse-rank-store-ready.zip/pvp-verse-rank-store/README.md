# PvP Verse Rank Store

Static PvP Verse storefront using Supabase for the rank catalog and order requests. The Minecraft side is intentionally independent of LuckPerms: fulfillment is expected to use your dev's custom rank plugin.

## Setup
1. Create/use the Supabase project for the shop.
2. Run `schema.sql` in Supabase SQL Editor.
3. Get the Project URL and **publishable key** from the Supabase Connect dialog.
4. Put them into `config.js`.
5. Deploy this folder to GitHub Pages, Cloudflare Pages, Netlify, etc.

The site works visually in demo mode before Supabase is configured. In live mode, rank cards load from `rank_products` and checkout inserts a `pending` row into `rank_orders`.

## Payment
The current build deliberately does **not** claim a payment succeeded. Connect your payment provider (for example, your chosen UPI/payment gateway) to the pending-order flow and verify payments server-side before changing `payment_status` to `paid`.

## Ranks
The included defaults are VIP ₹49/month, VIP+ ₹99/month, and MVP ₹149/month. MVP ₹149/month is the pricing already established; the other two are editable defaults and should be changed to your final prices before launch.

Staff ranks are not sold.
